<?php
if($_GET['q']=='login'){
}
?>