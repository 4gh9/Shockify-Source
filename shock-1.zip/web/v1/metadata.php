<?php
echo file_get_contents("https://thumbnails.roblox.com/v1/metadata");

?>